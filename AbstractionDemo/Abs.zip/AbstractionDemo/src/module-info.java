/**
 * 
 */
/**
 * @author minkhantthu
 *
 */
module AbstractionDemo {
}