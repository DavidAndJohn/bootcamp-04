package con.jdc.mkt.abstracttest;

public class Tiger extends Animal {

	@Override
	boolean eatYet() {
		return true;
	}

	@Override
	boolean checkMedicalCare() {
		return true;
	}

	

}
