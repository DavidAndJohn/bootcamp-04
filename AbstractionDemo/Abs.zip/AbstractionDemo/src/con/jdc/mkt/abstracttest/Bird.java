package con.jdc.mkt.abstracttest;

public class Bird  extends Animal{
	
	
	
	

	@Override
	boolean eatYet() {
		return false;
	}

	@Override
	boolean checkMedicalCare() {
		return true;
	}

	

}
