package con.jdc.mkt.abstracttest;

public class Leopard extends Animal{

	@Override
	boolean eatYet() {
		return false;
	}

	@Override
	boolean checkMedicalCare() {
		return false;
	}

}
