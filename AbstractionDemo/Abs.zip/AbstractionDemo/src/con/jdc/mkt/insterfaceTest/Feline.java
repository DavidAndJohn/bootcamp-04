package con.jdc.mkt.insterfaceTest;

public interface Feline {

	abstract void makeSound();
	
}
