package con.jdc.mkt.insterfaceTest;

public interface Canie {

	void doSomething();
}
